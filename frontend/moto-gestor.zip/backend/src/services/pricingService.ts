import { prisma } from "./prismaClient";

export async function calculatePrice({ 
  companyId, 
  originBairro, 
  distanceKm 
}: {
  companyId: string;
  originBairro?: string | null;
  distanceKm?: number | null;
}) {
  if (originBairro) {
    const byBairro = await prisma.regraPreco.findFirst({
      where: { 
        companyId, 
        type: "bairro", 
        key: {
          equals: originBairro,
          mode: 'insensitive' 
        }
      }
    });

    if (byBairro) {
      return Math.max(byBairro.basePrice, byBairro.minPrice ?? 0);
    }
  }

  if (typeof distanceKm === "number" && distanceKm > 0) {
    const kmRule = await prisma.regraPreco.findFirst({
      where: { companyId, type: "km" },
      orderBy: { createdAt: "desc" }
    });

    if (kmRule) {
      const price = kmRule.basePrice + ((kmRule.perKm ?? 0) * distanceKm);
      return Math.max(price, kmRule.minPrice ?? 0);
    }
  }

  const defaultRule = await prisma.regraPreco.findFirst({
    where: { companyId },
    orderBy: { createdAt: "desc" }
  });

  return defaultRule?.basePrice ?? 10.00;
}
